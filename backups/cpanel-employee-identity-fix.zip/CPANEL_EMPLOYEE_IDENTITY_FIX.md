Employee NIN and email production patch
======================================

Live deployment has not been performed from this workspace. The patch changes
only the Employee model's optional identity fields and the employee form. It
preserves the other methods and fields in the server's existing files, and
backs up the original source files outside the web application directory.

1. Upload optional_employee_identity_patch.py using cPanel File Manager into:

   /home/hippbcvk/admin.hipposecurity.com/

2. Open cPanel Terminal. Activate the existing application's environment:

   ```bash
   source /home/hippbcvk/virtualenv/admin.hipposecurity.com/3.12/bin/activate
   cd /home/hippbcvk/admin.hipposecurity.com
   ```

   Use the application's existing environment variables in this terminal,
   including DJANGO_ENV, DJANGO_DB_ENGINE, SECRET_KEY, and DB_* as required by
   NewCompany/settings.py. Do not paste passwords or secret keys into chat.
   Confirm access before changing the files:

   ```bash
   python manage.py check --database default
   ```

3. Preview and apply the patch:

   ```bash
   python optional_employee_identity_patch.py
   python optional_employee_identity_patch.py --apply
   ```

4. Generate the migration against the server's own migration history, then
   apply it. Stop if any command fails and keep the error output:

   ```bash
   python manage.py makemigrations webroaster --name employee_optional_identity_live
   python manage.py migrate --noinput
   python manage.py check
   ```

5. Verify the model fields and the actual employee entry form:

   ```bash
   python manage.py shell -c "from webroaster.models import Employee; from webroaster.views import get_config, build_create_formset; f=build_create_formset(get_config('employees')).form(); print('NIN blank/null:', Employee._meta.get_field('national_id').blank, Employee._meta.get_field('national_id').null); print('Required:', f.fields['national_id'].required, f.fields['email'].required)"
   ```

   Expected: NIN blank/null: True True; Required: False False.

6. In cPanel > Setup Python App, restart the existing application serving
   admin.hipposecurityug.com. Reload the employee page and save the intended
   employee with NIN and email empty. Other required employee fields, including
   deployment area for a guard or supervisor, must still be completed.

The script supports the active models/hr.py and forms_hr.py layout and the
alternative models/human_resource/models.py layout from the pasted model.
It checks Python syntax before writing and can be rerun without repeating
its insertions. Supplied NINs retain uniqueness. Email retains its existing
uniqueness setting. Empty unique fields are stored as NULL.
