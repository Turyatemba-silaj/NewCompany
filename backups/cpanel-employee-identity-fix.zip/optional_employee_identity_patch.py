"""Patch the deployed employee model/form; run migrations separately afterwards."""

import argparse
import ast
import shutil
from datetime import datetime
from pathlib import Path


def find_class(source, name):
    matches = [node for node in ast.parse(source).body
               if isinstance(node, ast.ClassDef) and node.name == name]
    if len(matches) != 1:
        raise RuntimeError(f"Expected exactly one {name} class; found {len(matches)}")
    return matches[0]


def replace_lines(source, edits):
    lines = source.splitlines(keepends=True)
    for start, end, replacement in sorted(edits, reverse=True):
        lines[start:end] = [replacement]
    result = "".join(lines)
    compile(result, "patched_source", "exec")
    return result


def patch_model(source):
    employee = find_class(source, "Employee")
    fields = {}
    for node in employee.body:
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            for target in node.targets:
                if isinstance(target, ast.Name):
                    fields[target.id] = node
    edits = []
    null_email = False
    for name in ("national_id", "email"):
        node = fields[name]
        call = node.value
        keywords = {item.arg: item.value for item in call.keywords}
        unique = isinstance(keywords.get("unique"), ast.Constant) and keywords["unique"].value is True
        nullable = name == "national_id" or unique
        if name == "email":
            null_email = nullable
        updates = {"blank": True}
        if nullable:
            updates["null"] = True
        call.keywords = [item for item in call.keywords if item.arg not in updates]
        call.keywords.extend(ast.keyword(arg=key, value=ast.Constant(value=value))
                             for key, value in updates.items())
        edits.append((node.lineno - 1, node.end_lineno,
                      f"    {name} = {ast.unparse(call)}\n"))
    save = next((node for node in employee.body
                 if isinstance(node, ast.FunctionDef) and node.name == "save"), None)
    normalization = (
        '        # Normalize optional employee identity fields.\n'
        '        self.national_id = (self.national_id or "").strip() or None\n'
        f'        self.email = (self.email or "").strip() or {"None" if null_email else chr(34) + chr(34)}\n'
    )
    if "# Normalize optional employee identity fields." not in source:
        if save:
            first = save.body[0]
            insertion = first.lineno - 1
            if isinstance(first, ast.Expr) and isinstance(first.value, ast.Constant) and isinstance(first.value.value, str):
                insertion = first.end_lineno
            edits.append((insertion, insertion, normalization))
        else:
            edits.append((employee.end_lineno, employee.end_lineno,
                          '\n    def save(self, *args, **kwargs):\n' + normalization
                          + '        super().save(*args, **kwargs)\n'))
    return replace_lines(source, edits), null_email


def patch_form(source, null_email):
    employee_form = find_class(source, "EmployeeForm")
    if "# Optional employee identity form fields." in source:
        return source
    init = next((node for node in employee_form.body
                 if isinstance(node, ast.FunctionDef) and node.name == "__init__"), None)
    body = (
        '        # Optional employee identity form fields.\n'
        '        for field_name in ("national_id", "email"):\n'
        '            if field_name in self.fields:\n'
        '                self.fields[field_name].required = False\n'
        '                self.fields[field_name].widget.attrs.pop("required", None)\n'
        '                self.fields[field_name].empty_value = (\n'
        f'                    None if field_name == "national_id" or {null_email!r} else ""\n'
        '                )\n'
    )
    if init:
        if any(isinstance(node, ast.Return) for node in ast.walk(init)):
            raise RuntimeError("EmployeeForm.__init__ has a return; review before patching.")
        insertion = init.end_lineno
    else:
        insertion = employee_form.end_lineno
        body = '\n    def __init__(self, *args, **kwargs):\n        super().__init__(*args, **kwargs)\n' + body
    return replace_lines(source, [(insertion, insertion, body)])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path.cwd())
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    if not (root / "manage.py").is_file():
        raise RuntimeError("Run from the app root containing manage.py, or provide --root.")
    if (root / "webroaster/models/hr.py").is_file():
        model = root / "webroaster/models/hr.py"
        form = root / "webroaster/forms_hr.py"
    else:
        model = root / "webroaster/models/human_resource/models.py"
        form = root / "webroaster/forms/human_resource/forms.py"
    original_model = model.read_text(encoding="utf-8-sig")
    original_form = form.read_text(encoding="utf-8-sig")
    new_model, null_email = patch_model(original_model)
    new_form = patch_form(original_form, null_email)
    changes = [(model, original_model, new_model), (form, original_form, new_form)]
    for path, old, new in changes:
        print(("PATCH " if old != new else "OK    ") + str(path))
    if not args.apply:
        print("Preview only. Re-run with --apply to back up and update these files.")
        return
    backup = Path.home() / ".employee_identity_backups" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    backup.mkdir(parents=True, mode=0o700)
    for path, old, new in changes:
        if old == new:
            continue
        destination = backup / path.relative_to(root)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        destination.chmod(0o600)
        path.write_text(new, encoding="utf-8")
    print(f"Source backups: {backup}")
    print("Source patched. Next run:")
    print("  python manage.py makemigrations webroaster --name employee_optional_identity_live")
    print("  python manage.py migrate --noinput")
    print("  python manage.py check")
    print("Then restart the existing Python App in cPanel.")


if __name__ == "__main__":
    main()
